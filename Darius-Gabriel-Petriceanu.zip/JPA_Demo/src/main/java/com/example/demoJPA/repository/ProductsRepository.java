package com.example.demoJPA.repository;

import com.example.demoJPA.model.Products;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductsRepository extends JpaRepository<Products, String> {
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO products (code, name, description, stock, decimal) " +
            "VALUES (:code, :name, :description, :stock, :decimal)")
    void insertProduct(
            @Param("username") String code,
            @Param("lastName") String name,
            @Param("firstName") String description,
            @Param("phone") int stock,
            @Param("address") double decimal);

    //create an endpoint which displays all products
    @Query(nativeQuery = true, value = "SELECT * FROM products")
    List<Products> getAllProducts();
}
