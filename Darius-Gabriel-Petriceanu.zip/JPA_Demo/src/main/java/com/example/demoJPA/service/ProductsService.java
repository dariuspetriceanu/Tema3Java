package com.example.demoJPA.service;

import com.example.demoJPA.model.Products;
import com.example.demoJPA.repository.ProductsRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ProductsService {
    @Autowired
    ProductsRepository productsRepository;

    public void insertProduct(String code, String name, String description, int stock, double decimal){
        productsRepository.insertProduct(code, name, description, stock, decimal);
    }

    public List<Products> getAllProducts(){
        productsRepository.getAllProducts();
        return null;
    }
}
