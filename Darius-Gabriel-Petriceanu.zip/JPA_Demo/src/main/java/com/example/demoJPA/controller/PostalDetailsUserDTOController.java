package com.example.demoJPA.controller;

import com.example.demoJPA.service.PostalDetailsUserDTOService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class PostalDetailsUserDTOController {
    @Autowired
    PostalDetailsUserDTOService postalDetailsUserDTOService;

    @GetMapping("/getPostalDetails")
    public String getPostalDetails(@RequestParam String name){
        postalDetailsUserDTOService.getPostalDetails(name);
        return "Postal details obtained successfully!";
    }

    @GetMapping("/getDetails")
    public String getDetails(){
        postalDetailsUserDTOService.getDetails();
        return "Details obtained successfully!";
    }
}
