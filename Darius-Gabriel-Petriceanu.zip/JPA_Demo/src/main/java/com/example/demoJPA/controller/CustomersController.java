package com.example.demoJPA.controller;

import com.example.demoJPA.model.Customers;
import com.example.demoJPA.service.CustomersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomersController {
    @Autowired
    CustomersService customersService;

    @PostMapping(value = "/insertCustomer")
    public String insertCustomer(
            @RequestParam String username,
            @RequestParam String lastName,
            @RequestParam String firstName,
            @RequestParam String phone,
            @RequestParam String address,
            @RequestParam String city,
            @RequestParam String postalCode,
            @RequestParam String country) {

        customersService.insertCustomer(username, lastName, firstName, phone, address, city, postalCode, country);

        return "Customer inserted successfully!";
    }
}
