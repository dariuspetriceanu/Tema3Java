package com.example.demoJPA.service;

import com.example.demoJPA.model.Customers;
import com.example.demoJPA.repository.CustomersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomersService {
    @Autowired
    CustomersRepository customersRepository;

//    public Customers CreateCustomer(Customers c){
//        customersRepository.save(c);
//        return c;
//    }
    public void insertCustomer(String username, String lastName, String firstName, String phone, String address, String city, String postalCode, String country) {
        customersRepository.insertCustomer(username, lastName, firstName, phone, address, city, postalCode, country);
    }

}
