package com.example.demoJPA.model;

import jakarta.persistence.*;

@Entity
@Table(name = "customers")
public class PostalDetailsUserDTO {
    @Id
    @GeneratedValue
    private int id;
    private String address;
    private String phone;
    private String city;
    private String username;
    private String postalCode;
    @Id
    @Column(name = "id", table= "customers", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Column(name = "address", table= "customers", nullable = true)
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    @Column(name = "phone", table= "customers", nullable = true)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    @Column(name = "city", table= "customers", nullable = true)
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    @Column(name = "username", table= "customers", nullable = true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    @Column(name = "postalCode", table= "customers", nullable = true)
    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
}
