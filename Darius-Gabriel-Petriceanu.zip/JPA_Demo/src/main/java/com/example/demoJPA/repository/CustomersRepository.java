package com.example.demoJPA.repository;

import com.example.demoJPA.model.Customers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

// <model name, PK data type>
@Repository
public interface CustomersRepository extends JpaRepository<Customers, Integer> {
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO customers (username, last_name, first_name, phone, address, city, postalCode, country) " +
            "VALUES (:username, :lastName, :firstName, :phone, :address, :city, :postalCode, :country)")
    void insertCustomer(
            @Param("username") String username,
            @Param("lastName") String lastName,
            @Param("firstName") String firstName,
            @Param("phone") String phone,
            @Param("address") String address,
            @Param("city") String city,
            @Param("postalCode") String postalCode,
            @Param("country") String country);
}
