package com.example.demoJPA.service;

import com.example.demoJPA.model.Orders;
import com.example.demoJPA.repository.OrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;

public class OrdersService {
    @Autowired
    OrdersRepository ordersRepository;

    public List<Orders> getCustomerOrders() {
        ordersRepository.getCustomerOrders();
        return null;
    }

    public void insertOrder(Integer id, Date orderDate, Date shippedDate, String status, String comments) {
        ordersRepository.insertOrder(id, orderDate, shippedDate, status, comments);
    }

}
