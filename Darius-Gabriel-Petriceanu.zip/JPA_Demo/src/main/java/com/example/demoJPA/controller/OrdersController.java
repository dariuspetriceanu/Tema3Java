package com.example.demoJPA.controller;

import com.example.demoJPA.model.Orders;
import com.example.demoJPA.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class OrdersController {
    @Autowired
    OrdersService ordersService;
    @GetMapping("/getCustomerOrders")
    public List<Orders> getCustomerOrders(){ return ordersService.getCustomerOrders(); }

    @PostMapping(value = "/insertOrder")
    public String insertOrder(
            @RequestParam Integer id,
            @RequestParam Date order_date,
            @RequestParam Date shipped_date,
            @RequestParam String status,
            @RequestParam String comments){

        ordersService.insertOrder(id, order_date, shipped_date, status, comments);

        return "Order inserted successfully!";
    }

    public static Date generateRandomDate(Random random) {
        long currentTimeMillis = System.currentTimeMillis();
        long offset = TimeUnit.DAYS.toMillis(random.nextInt(365)); // Random offset up to 1 year

        long randomTimeMillis = currentTimeMillis - offset;
        return new Date(randomTimeMillis);
    }
    // INSERTING 10 PRODUCTS
    @PostMapping("/insertOrders")
    public String insertOrders(){
        Random random = new Random();
        for(int i = 0; i < 5; i++){
            Integer id = i;
            Date order_date = generateRandomDate(random);
            Date shipped_date = generateRandomDate(random);
            String status = "Status " + i;
            String comment = "Comment " + i;

            ordersService.insertOrder(id, order_date, shipped_date, status, comment);
        }
        return "Orders inserted successfully";
    }
}
