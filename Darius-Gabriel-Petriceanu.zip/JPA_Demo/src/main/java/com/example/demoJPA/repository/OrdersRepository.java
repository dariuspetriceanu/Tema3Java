package com.example.demoJPA.repository;

import com.example.demoJPA.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
// -> create an endpoint that can display all orders belonging to a customer
@Repository
public interface OrdersRepository extends JpaRepository<Orders, Integer> {
    // create an endpoint that can display all orders belonging to a customer
    @Query(nativeQuery = true, value ="SELECT o.id AS order_id, o.order_date, o.shipped_date, o.status, o.comments," +
                                      "c.id AS customer_id, c.username, c.last_name, c.first_name," +
                                      "c.phone, c.address, c.city, c.postalCode, c.country" +
                                      "FROM ORDERS o" +
                                      "JOIN CUSTOMERS c ON o.customer_ID = c.id" +
                                      "WHERE c.id = :customerId;")
    List<Orders> getCustomerOrders();

    // -> add 5 products to an order belonging to the customer
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO orders (id, order_date, shipped_date, status, comments)" +
                                        "VALUES (:id, :order_date, :shipped_date, :status, :comments)" +
                                        "FROM ORDERS WHERE customer_id = :customer_id;" )
    void insertOrder(
            @Param("customer_id") Integer id,
            @Param("order_date") Date order_date,
            @Param("shipped_date") Date shipped_date,
            @Param("status") String status,
            @Param("comment") String comments);
}
