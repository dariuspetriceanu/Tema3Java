package com.example.demoJPA.service;

import com.example.demoJPA.model.Customers;
import com.example.demoJPA.repository.PostalDetailsUserDTORepository;
import org.springframework.beans.factory.annotation.Autowired;

public class PostalDetailsUserDTOService {
    @Autowired
    PostalDetailsUserDTORepository postalDetailsUserDTORepository;
    public void getPostalDetails(String name) {
        postalDetailsUserDTORepository.getPostalDetails(name);
    }

    public void getDetails() {
        postalDetailsUserDTORepository.getDetails();
    }
}
