package com.example.demoJPA.controller;

import com.example.demoJPA.model.Products;
import com.example.demoJPA.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public class ProductsController {
    @Autowired
    ProductsService productsService;

    @PostMapping(value = "/insertProduct")
    public String insertProduct(
            @RequestParam String code,
            @RequestParam String name,
            @RequestParam String description,
            @RequestParam int stock,
            @RequestParam double decimal){

        productsService.insertProduct(code, name, description, stock, decimal);

        return "Product inserted successfully!";
    }
// INSERTING 10 PRODUCTS
    @PostMapping("/insertProducts")
    public String insertProducts(){
        for(int i = 0; i < 10; i++){
            String code = "P" + i;
            String name = "Product " + i;
            String description = "Description for Product " + i;
            short stock = (short) (100 + i); // Example stock value
            double price = 10.99 + i;  // Example price value

            productsService.insertProduct(code, name, description, stock, price);
        }
        return "Products inserted successfully";
    }

    @GetMapping("/getAllProducts")
    public List<Products> getAllProducts(){
        return productsService.getAllProducts();
    }
}
