package com.example.demoJPA.repository;

import com.example.demoJPA.model.Customers;
import com.example.demoJPA.model.PostalDetailsUserDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostalDetailsUserDTORepository {

    // -> create an endpoint which will return the postal details of an user, given his username as input
    @Query(nativeQuery = true, value = "SELECT customers.postalCode FROM customers where name = :name;")
    String getPostalDetails(String name);

    // -> create a DTO to return only the address, phone and city of the customer, called PostalDetailsUserDTO
    @Query(nativeQuery = true, value = "SELECT customers.address, customers.phone, customers.city FROM customers;")
    List<PostalDetailsUserDTO> getDetails();


}
